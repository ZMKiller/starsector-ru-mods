package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.ModSpecAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.codex.CodexDataV2;
import static com.fs.starfarer.api.impl.codex.CodexDataV2.getEntry;
import static com.fs.starfarer.api.impl.codex.CodexDataV2.getFighterEntryId;
import static com.fs.starfarer.api.impl.codex.CodexDataV2.getHullmodEntryId;
import static com.fs.starfarer.api.impl.codex.CodexDataV2.getShipEntryId;
import static com.fs.starfarer.api.impl.codex.CodexDataV2.getWeaponEntryId;
import com.fs.starfarer.api.impl.codex.CodexDialogAPI;
import com.fs.starfarer.api.impl.codex.CodexEntryPlugin;
import com.fs.starfarer.api.impl.codex.CodexEntryV2;
import com.fs.starfarer.api.loading.Description;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.CustomPanelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.UIPanelAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.HashSet;
import java.util.Set;

/* stuffstuffstuffstuffstuff */

public class CodexSetup {
    public static void run() {
         
        //fake commodity info
        CodexEntryV2 fakeaicommodityinfo = new TMICodexEntry("codex_commodity_ai_cores_tmi", Global.getSettings().getCommoditySpec("ai_cores").getName(), Global.getSettings().getCommoditySpec("ai_cores").getIconName(), Global.getSettings().getCommoditySpec("ai_cores")) {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addPara(Global.getSettings().getDescription("ai_cores", Description.Type.RESOURCE).getText1(), 3f);}public void createTitleForList(TooltipMakerAPI info, float width, CodexEntryPlugin.ListMode mode) {info.addPara(Global.getSettings().getCommoditySpec("ai_cores").getName(), Misc.getBasePlayerColor(), 0f);if (mode == CodexEntryPlugin.ListMode.RELATED_ENTRIES) {info.addPara("Special item", Misc.getGrayColor(), 0f);}}};
        addEntry(fakeaicommodityinfo, CodexDataV2.getEntry("commodities"));
        fakeaicommodityinfo.addRelatedEntry("alpha_core");
        for (CommoditySpecAPI spec: Global.getSettings().getAllCommoditySpecs()) {if (spec.hasTag(Commodities.TAG_AI_CORE) && !spec.hasTag(Tags.HIDE_IN_CODEX)) {fakeaicommodityinfo.addRelatedEntry(CodexDataV2.getCommodityEntryId(spec.getId()));}}
        //real faction info
        CodexEntryPlugin factionCat = CodexDataV2.getEntry("tmi_factions");
        
        for (FactionAPI faction : Global.getSector().getAllFactions()) {
            if ((Global.getSector().getFaction(faction.getId()) != Global.getSector().getPlayerFaction()) && (faction.isShowInIntelTab())) {
                CodexEntryV2 factioninfo = new TMICodexEntry("tmi_factions" + faction.getId(), Misc.ucFirst(faction.getDisplayName()),
                        faction.getCrest()) {
                    @Override
                    public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {
                        float opad = 10;
                        //float pad = 3;
                        //float initPad = Global.CODEX_TOOLTIP_MODE ? 0 : opad;

                        //info.setParaInsigniaLarge();
                        //info.addPara("How to use?", initPad);
                        //info.setParaFontDefault();
                        //info.addPara("On your left, you see a list of factions.", pad);
                        //info.addPara("On your right, you see a list of related entries if applicable.", pad);
                        try {
                        Description desc = Global.getSettings().getDescription(faction.getId(), Description.Type.FACTION);
                        TooltipMakerAPI section = info.beginImageWithText(faction.getCrest(), 64);
                        String str = desc.getText1();//String str = desc.getText1FirstPara();
                        section.addPara(str, opad);
                        info.addImageWithText(opad);
                        } catch (Exception ex) {

                        }
                        int iicaptain = 0;
                        for (int i = 0; i <= 10; i++) {
                            String string = faction.getId()+i;
                            if (!Global.getSettings().getString("timid_tmi", string).equals(String.format(Global.getSettings().getString("timid_tmi", "tmi_debug"), string))) {if(iicaptain==0){iicaptain++;info.addSectionHeading(Global.getSettings().getString("timid_tmi", "faction_header"), Alignment.TMID, 10f);}info.addPara(Global.getSettings().getString("timid_tmi", string), 5f);}
                            //if (!Global.getSettings().getString("timid_tmi", string).equals(String.format(Global.getSettings().getString("timid_tmi", "tmi_debug"), string))) {String text = Global.getSettings().getString("timid_tmi", string);if(iicaptain==0){iicaptain++;info.addSectionHeading(Global.getSettings().getString("timid_tmi", "faction_header"), Alignment.TMID, 10f);}info.addPara(String.format("%s: %s", string, text), 5f);}
                        }  
                        if (!faction.getIllegalCommodities().isEmpty()) {
                            Set<String> illegals = new HashSet<>();
                            //info.beginIconGroup();
                            //info.setIconSpacingMedium();
                            for (String illegal: faction.getIllegalCommodities()) {
                                if ("ai_cores".equals(illegal)) {
                                    illegals.add(CodexDataV2.getCommodityEntryId("ai_cores_tmi"));
                                } else {illegals.add(CodexDataV2.getCommodityEntryId(illegal));}
                                //info.addIcons(Global.getSettings().getCommoditySpec(illegal), 1, IconRenderMode.NORMAL);
                            }
                            //info.addIconGroup(32, 2, opad);
                            info.addCodexEntries("Illegal Commodities", illegals, true, opad);
                        } 
                    }
                };
                if (!Global.getSector().getFaction(faction.getId()).getKnownShips().isEmpty()) {
                    CodexEntryV2 factionfrigateinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_frigates", "Ships (Frigate)","graphics/hullmods/timid_tmifrigate.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "frigatea"), 5f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "frigate"));}};
                    CodexEntryV2 factiondestroyerinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_destroyers", "Ships (Destroyer)","graphics/hullmods/timid_tmiship.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "destroyera"), 5f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "destroyer"));}};
                    CodexEntryV2 factioncruiserinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_cruisers", "Ships (Cruiser)","graphics/hullmods/timid_tmicruiser.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "cruisera"), 5f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "cruiser"));}};
                    CodexEntryV2 factioncapitalshipinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_capitalships", "Ships (Capital Ship)","graphics/hullmods/timid_tmicapitalship.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "capitalshipa"), 5f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "capitalship"));}};
                    int frigate = 0;
                    int destroyer = 0;
                    int cruiser = 0;
                    int capital_ship = 0;
                    for (String ship : Global.getSector().getFaction(faction.getId()).getKnownShips()) {
                         try {if (Global.getSettings().getHullSpec(ship) != null && getShipEntryId(ship) != null) {
                            if (Global.getSettings().getHullSpec(ship).getHullSize() == HullSize.FRIGATE) {factionfrigateinfo.addRelatedEntry(getEntry(getShipEntryId(ship)));frigate++;}
                            if (Global.getSettings().getHullSpec(ship).getHullSize() == HullSize.DESTROYER) {factiondestroyerinfo.addRelatedEntry(getEntry(getShipEntryId(ship)));destroyer++;}
                            if (Global.getSettings().getHullSpec(ship).getHullSize() == HullSize.CRUISER) {factioncruiserinfo.addRelatedEntry(getEntry(getShipEntryId(ship)));cruiser++;}
                            if (Global.getSettings().getHullSpec(ship).getHullSize() == HullSize.CAPITAL_SHIP) {factioncapitalshipinfo.addRelatedEntry(getEntry(getShipEntryId(ship)));capital_ship++;}
                         }
                         } catch (Exception ex) {}
                    }
                    if (frigate>0) addEntry(factionfrigateinfo, factioninfo);factioninfo.addRelatedEntry(factionfrigateinfo);
                    if (destroyer>0) addEntry(factiondestroyerinfo, factioninfo);factioninfo.addRelatedEntry(factiondestroyerinfo);
                    if (cruiser>0) addEntry(factioncruiserinfo, factioninfo);factioninfo.addRelatedEntry(factioncruiserinfo);
                    if (capital_ship>0) addEntry(factioncapitalshipinfo, factioninfo);factioninfo.addRelatedEntry(factioncapitalshipinfo);
                    
                }
                if (!Global.getSector().getFaction(faction.getId()).getPriorityShips().isEmpty() || !Global.getSector().getFaction(faction.getId()).getPriorityWeapons().isEmpty() || !Global.getSector().getFaction(faction.getId()).getPriorityWeapons().isEmpty() || !Global.getSector().getFaction(faction.getId()).getPriorityFighters().isEmpty()) {
                    CodexEntryV2 factionpriorityinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_priority", "Priority Sorts",
                            "graphics/hullmods/timid_tmipriority.png") {@Override public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "prioritysorta"), 5f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "prioritysort"));}};
                    for (String priorityship : Global.getSector().getFaction(faction.getId()).getPriorityShips()) {
                        try {if (Global.getSettings().getHullSpec(priorityship) != null && CodexDataV2.getEntry(CodexDataV2.getShipEntryId(priorityship)) != null) {
                            factionpriorityinfo.addRelatedEntry(CodexDataV2.getEntry(CodexDataV2.getShipEntryId(priorityship)));
                        }
                        } catch (Exception ex) {}
                    }
                    for (String prioritywings : Global.getSector().getFaction(faction.getId()).getPriorityFighters()) {
                        try {if (Global.getSettings().getFighterWingSpec(prioritywings) != null && CodexDataV2.getEntry(CodexDataV2.getFighterEntryId(prioritywings)) != null) {
                            factionpriorityinfo.addRelatedEntry(CodexDataV2.getEntry(CodexDataV2.getFighterEntryId(prioritywings)));
                        }
                        } catch (Exception ex) {}
                    }
                    for (String prioritymod : Global.getSector().getFaction(faction.getId()).getPriorityHullMods()) {
                        try {if (Global.getSettings().getHullModSpec(prioritymod) != null && CodexDataV2.getEntry(CodexDataV2.getHullmodEntryId(prioritymod)) != null) {
                            factionpriorityinfo.addRelatedEntry(CodexDataV2.getEntry(CodexDataV2.getHullmodEntryId(prioritymod)));
                        }
                        } catch (Exception ex) {}
                    }
                    for (String priorityweapons : Global.getSector().getFaction(faction.getId()).getPriorityWeapons()) {
                        try {if (Global.getSettings().getWeaponSpec(priorityweapons) != null && CodexDataV2.getEntry(CodexDataV2.getWeaponEntryId(priorityweapons)) != null) {
                            factionpriorityinfo.addRelatedEntry(CodexDataV2.getEntry(CodexDataV2.getWeaponEntryId(priorityweapons)));
                        }
                        } catch (Exception ex) {}
                    }
                    addEntry(factionpriorityinfo, factioninfo);
                    factioninfo.addRelatedEntry(factionpriorityinfo);
                }
                if (!Global.getSector().getFaction(faction.getId()).getKnownFighters().isEmpty()) {
                        CodexEntryV2 factionwinginfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_wings", "Wings",
                            "graphics/hullmods/timid_tmifighters.png") {
                        @Override
                        public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "winga"), 5f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "wing"));info.addPara(Global.getSettings().getString("timid_tmi", "wingb"), 0f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "wing1"));info.addPara(Global.getSettings().getString("timid_tmi", "wingc"), 0f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "wing2"));info.addPara(Global.getSettings().getString("timid_tmi", "wingd"), 0f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "wing3"));info.addPara(Global.getSettings().getString("timid_tmi", "winge"), 0f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "wing4"));}
                    };
                    for (String wing : Global.getSector().getFaction(faction.getId()).getKnownFighters()) {
                        try {if (Global.getSettings().getFighterWingSpec(wing) != null && getFighterEntryId(wing) != null) {
                            factionwinginfo.addRelatedEntry(getEntry(getFighterEntryId(wing)));
                        }
                        } catch (Exception ex) {}
                    }
                    addEntry(factionwinginfo, factioninfo);
                    factioninfo.addRelatedEntry(factionwinginfo);
                }
                if (!Global.getSector().getFaction(faction.getId()).getKnownWeapons().isEmpty()) {
                        CodexEntryV2 factionballisticweaponinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_ballisticweapons", "Weapons (Ballistic)", "graphics/hullmods/timid_tmiweapons.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "ballistica"), 5f, new Color[]{Misc.MOUNT_BALLISTIC, Misc.MOUNT_BALLISTIC, Misc.MOUNT_HYBRID,Misc.MOUNT_COMPOSITE,Misc.MOUNT_UNIVERSAL, Misc.MOUNT_BALLISTIC, Misc.MOUNT_BALLISTIC}, Global.getSettings().getString("timid_tmi", "ballistic"), Global.getSettings().getString("timid_tmi", "ballistic"), Global.getSettings().getString("timid_tmi", "hybrid"), Global.getSettings().getString("timid_tmi", "composite"), Global.getSettings().getString("timid_tmi", "universal"), Global.getSettings().getString("timid_tmi", "ballistic"), Global.getSettings().getString("timid_tmi", "ballistic"));}};
                        CodexEntryV2 factioncompositeweaponinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_compositeweapons", "Weapons (Composite)", "graphics/hullmods/timid_tmicomposite.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "compositea"), 5f, new Color[]{Misc.MOUNT_COMPOSITE, Misc.MOUNT_COMPOSITE, Misc.MOUNT_BALLISTIC,Misc.MOUNT_MISSILE,Misc.MOUNT_UNIVERSAL, Misc.MOUNT_COMPOSITE, Misc.MOUNT_COMPOSITE}, Global.getSettings().getString("timid_tmi", "composite"), Global.getSettings().getString("timid_tmi", "composite"), Global.getSettings().getString("timid_tmi", "ballistic"), Global.getSettings().getString("timid_tmi", "missile"), Global.getSettings().getString("timid_tmi", "universal"), Global.getSettings().getString("timid_tmi", "composite"), Global.getSettings().getString("timid_tmi", "composite"));}};
                        CodexEntryV2 factionmissileweaponinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_missileweapons", "Weapons (Missile)", "graphics/hullmods/timid_tmimissiles.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "missilea"), 5f, new Color[]{Misc.MOUNT_MISSILE, Misc.MOUNT_MISSILE, Misc.MOUNT_COMPOSITE,Misc.MOUNT_SYNERGY,Misc.MOUNT_UNIVERSAL, Misc.MOUNT_MISSILE, Misc.MOUNT_MISSILE}, Global.getSettings().getString("timid_tmi", "missile"), Global.getSettings().getString("timid_tmi", "missile"), Global.getSettings().getString("timid_tmi", "composite"), Global.getSettings().getString("timid_tmi", "synergy"), Global.getSettings().getString("timid_tmi", "universal"), Global.getSettings().getString("timid_tmi", "missile"), Global.getSettings().getString("timid_tmi", "missile"));}};
                        CodexEntryV2 factionsynergyweaponinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_synergyweapons", "Weapons (Synergy)", "graphics/hullmods/timid_tmisynergy.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "synergya"), 5f, new Color[]{Misc.MOUNT_SYNERGY, Misc.MOUNT_SYNERGY, Misc.MOUNT_ENERGY,Misc.MOUNT_MISSILE,Misc.MOUNT_UNIVERSAL, Misc.MOUNT_SYNERGY, Misc.MOUNT_SYNERGY}, Global.getSettings().getString("timid_tmi", "synergy"), Global.getSettings().getString("timid_tmi", "synergy"), Global.getSettings().getString("timid_tmi", "energy"), Global.getSettings().getString("timid_tmi", "missile"), Global.getSettings().getString("timid_tmi", "universal"), Global.getSettings().getString("timid_tmi", "synergy"), Global.getSettings().getString("timid_tmi", "synergy"));}};
                        CodexEntryV2 factionenergyweaponinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_energyweapons", "Weapons (Energy)", "graphics/hullmods/timid_tmienergy.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "energya"), 5f, new Color[]{Misc.MOUNT_ENERGY, Misc.MOUNT_ENERGY, Misc.MOUNT_HYBRID,Misc.MOUNT_SYNERGY,Misc.MOUNT_UNIVERSAL, Misc.MOUNT_ENERGY, Misc.MOUNT_ENERGY}, Global.getSettings().getString("timid_tmi", "energy"), Global.getSettings().getString("timid_tmi", "energy"), Global.getSettings().getString("timid_tmi", "hybrid"), Global.getSettings().getString("timid_tmi", "synergy"), Global.getSettings().getString("timid_tmi", "universal"), Global.getSettings().getString("timid_tmi", "energy"), Global.getSettings().getString("timid_tmi", "energy"));}};
                        CodexEntryV2 factionhybridweaponinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_hybridweapons", "Weapons (Hybrid)", "graphics/hullmods/timid_tmihybrid.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "hybrida"), 5f, new Color[]{Misc.MOUNT_HYBRID, Misc.MOUNT_HYBRID, Misc.MOUNT_BALLISTIC,Misc.MOUNT_ENERGY,Misc.MOUNT_UNIVERSAL, Misc.MOUNT_HYBRID, Misc.MOUNT_HYBRID}, Global.getSettings().getString("timid_tmi", "hybrid"), Global.getSettings().getString("timid_tmi", "hybrid"), Global.getSettings().getString("timid_tmi", "ballistic"), Global.getSettings().getString("timid_tmi", "energy"), Global.getSettings().getString("timid_tmi", "universal"), Global.getSettings().getString("timid_tmi", "hybrid"), Global.getSettings().getString("timid_tmi", "hybrid"));}};
                        CodexEntryV2 factionuniversalweaponinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_universalweapons", "Weapons (Universal)", "graphics/hullmods/timid_blank_hmodicon.png") {public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "universala"), 5f, new Color[]{Misc.MOUNT_UNIVERSAL, Misc.MOUNT_UNIVERSAL, Misc.MOUNT_UNIVERSAL,Misc.MOUNT_UNIVERSAL}, Global.getSettings().getString("timid_tmi", "universal"), Global.getSettings().getString("timid_tmi", "universal"), Global.getSettings().getString("timid_tmi", "universal"));}};
                        int b_weapon = 0;
                        int c_weapon = 0;
                        int m_weapon = 0;
                        int s_weapon = 0;
                        int e_weapon = 0;
                        int h_weapon = 0;
                        int u_weapon = 0;
                    for (String weapon : Global.getSector().getFaction(faction.getId()).getKnownWeapons()) {
                        try {if (Global.getSettings().getWeaponSpec(weapon) != null && getWeaponEntryId(weapon) != null) {
                            if (Global.getSettings().getWeaponSpec(weapon).getMountType() == WeaponType.BALLISTIC) {factionballisticweaponinfo.addRelatedEntry(getEntry(getWeaponEntryId(weapon)));b_weapon++;}
                            if (Global.getSettings().getWeaponSpec(weapon).getMountType() == WeaponType.COMPOSITE) {factioncompositeweaponinfo.addRelatedEntry(getEntry(getWeaponEntryId(weapon)));c_weapon++;}
                            if (Global.getSettings().getWeaponSpec(weapon).getMountType() == WeaponType.MISSILE) {factionmissileweaponinfo.addRelatedEntry(getEntry(getWeaponEntryId(weapon)));m_weapon++;}
                            if (Global.getSettings().getWeaponSpec(weapon).getMountType() == WeaponType.SYNERGY) {factionsynergyweaponinfo.addRelatedEntry(getEntry(getWeaponEntryId(weapon)));s_weapon++;}
                            if (Global.getSettings().getWeaponSpec(weapon).getMountType() == WeaponType.ENERGY) {factionenergyweaponinfo.addRelatedEntry(getEntry(getWeaponEntryId(weapon)));e_weapon++;}
                            if (Global.getSettings().getWeaponSpec(weapon).getMountType() == WeaponType.HYBRID) {factionhybridweaponinfo.addRelatedEntry(getEntry(getWeaponEntryId(weapon)));h_weapon++;}
                            if (Global.getSettings().getWeaponSpec(weapon).getMountType() == WeaponType.UNIVERSAL) {factionuniversalweaponinfo.addRelatedEntry(getEntry(getWeaponEntryId(weapon)));u_weapon++;}
                        }
                        } catch (Exception ex) {}
                    }
                    if (b_weapon>0) addEntry(factionballisticweaponinfo, factioninfo);factioninfo.addRelatedEntry(factionballisticweaponinfo);
                    if (c_weapon>0) addEntry(factioncompositeweaponinfo, factioninfo);factioninfo.addRelatedEntry(factioncompositeweaponinfo);
                    if (m_weapon>0) addEntry(factionmissileweaponinfo, factioninfo);factioninfo.addRelatedEntry(factionmissileweaponinfo);
                    if (s_weapon>0) addEntry(factionsynergyweaponinfo, factioninfo);factioninfo.addRelatedEntry(factionsynergyweaponinfo);
                    if (e_weapon>0) addEntry(factionenergyweaponinfo, factioninfo);factioninfo.addRelatedEntry(factionenergyweaponinfo);
                    if (h_weapon>0) addEntry(factionhybridweaponinfo, factioninfo);factioninfo.addRelatedEntry(factionhybridweaponinfo);
                    if (u_weapon>0) addEntry(factionuniversalweaponinfo, factioninfo);factioninfo.addRelatedEntry(factionuniversalweaponinfo);
                }
                if (Global.getSector().getFaction(faction.getId()).getKnownHullMods() != null && !Global.getSector().getFaction(faction.getId()).getKnownHullMods().isEmpty()) {
                        CodexEntryV2 factionhullmodinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_hullmods", "Hullmods",
                            "graphics/hullmods/timid_tmihullmods.png") {
                        @Override
                        public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {
                        info.addImage(faction.getLogo(), 10f);info.addPara(Global.getSettings().getString("timid_tmi", "hullmoda"), 5f, Misc.getHighlightColor(), Global.getSettings().getString("timid_tmi", "hullmod"), Global.getSettings().getString("timid_tmi", "hullmod2"));info.addPara(Global.getSettings().getString("timid_tmi", "hullmodb"), 5f);info.addPara(Global.getSettings().getString("timid_tmi", "hullmodc"), 5f);info.addPara(Global.getSettings().getString("timid_tmi", "hullmodd"), 5f);}
                    };
                    for (String modspec : Global.getSector().getFaction(faction.getId()).getKnownHullMods()) {
                        try {if (Global.getSettings().getHullModSpec(modspec) != null && getHullmodEntryId(modspec) != null) {
                            factionhullmodinfo.addRelatedEntry(getEntry(getHullmodEntryId(modspec)));
                        }
                        } catch (Exception ex) {}
                    }
                    addEntry(factionhullmodinfo, factioninfo);
                    factioninfo.addRelatedEntry(factionhullmodinfo);
                }
                /*
                if (!Global.getSector().getFaction(faction.getId()).getKnownIndustries().isEmpty()) {
                        CodexEntryV2 factionindustryinfo = new TMICodexEntry("tmi_factions" + faction.getId() + "_industries", "Industries",
                            "graphics/hullmods/timid_tmiindustry.png") {
                        @Override
                        public void createCustomDetailImpl(TooltipMakerAPI info, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex) {
                        }
                    };
                    for (String industry : Global.getSector().getFaction(faction.getId()).getKnownIndustries()) {
                        try {if (Global.getSettings().getIndustrySpec(industry) != null && CodexDataV2.getEntry(CodexDataV2.getIndustryEntryId(industry)) != null) {
                            factionindustryinfo.addRelatedEntry(CodexDataV2.getEntry(CodexDataV2.getIndustryEntryId(industry)));
                        }
                        } catch (Exception ex) {}
                    }
                    addEntry(factionindustryinfo, factioninfo);
                    factioninfo.addRelatedEntry(factionindustryinfo);
                }*/
                addEntry(factioninfo, factionCat);
            }
        }
    }

    public static void addEntry(CodexEntryV2 entry, CodexEntryPlugin parent, String... related) {
        if (related != null) {
            for (String relatedId : related) entry.addRelatedEntry(relatedId);
        }

        // add ourselves as a related entry to the commodities
        if (related != null) {
            for (String relatedId : related) {
                CodexDataV2.getEntry(relatedId).addRelatedEntry(entry);
            }
        }

        CodexDataV2.ENTRIES.put(entry.getId(), entry);
        parent.addChild(entry);
    }

    // runcode exerelin.codex.CodexSetup.rerun();
    public static void rerun() {
        CodexEntryPlugin factionCat = CodexDataV2.getEntry("tmi_factions");
        factionCat.getChildren().clear();
        run();
    }


    public static abstract class TMICodexEntry extends CodexEntryV2 {

        public TMICodexEntry(String id, String title, String icon) {
            super(id, title, icon);
        }

        public TMICodexEntry(String id, String title, String icon, Object param) {
            super(id, title, icon, param);
        }

        @Override
        public boolean isCategory() {
            return false;
        }

        @Override
        public boolean hasCustomDetailPanel() {
            return true;
        }

        @Override
        public void createCustomDetail(CustomPanelAPI panel, UIPanelAPI relatedEntries, CodexDialogAPI codex) {
            float width = panel.getPosition().getWidth();
            float opad = 10f;
            float horzBoxPad = 30f;

            // the right width for a tooltip wrapped in a box to fit next to relatedEntries
            // 290 is the width of the related entries widget, but it may be null
            float tw = width - opad - + 10f;
            if (relatedEntries != null) {
                tw = tw - 290 - horzBoxPad;
            }

            TooltipMakerAPI tt = panel.createUIElement(tw, 0, false);

            createCustomDetailImpl(tt, panel, tw, relatedEntries, codex);

            panel.updateUIElementSizeAndMakeItProcessInput(tt); // this is needed to make it the right size
            UIPanelAPI box = panel.wrapTooltipWithBox(tt);
            panel.addComponent(box).inTL(0, 0);

            if (relatedEntries != null) {
                panel.addComponent(relatedEntries).inTR(0f, 0f);
            }

            float height = tt.getPosition().getHeight();
            if (relatedEntries != null) {
                height = Math.max(height, relatedEntries.getPosition().getHeight());
            }

            panel.getPosition().setSize(width, height + opad * 3);
        }

        public abstract void createCustomDetailImpl(TooltipMakerAPI tt, CustomPanelAPI panel, float ttWidth, UIPanelAPI relatedEntries, CodexDialogAPI codex);

        @Override
        public ModSpecAPI getSourceMod() {
            return Global.getSettings().getModManager().getModSpec("timid_tmi");
        }
    }
}