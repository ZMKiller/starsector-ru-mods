/*TBD: Move strings out of code for easier translation
 * https://fractalsoftworks.com/forum/index.php?topic=19405.0
 */

package FleetSizeByDP;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import FleetSizeByDP.com.starfarer.api.impl.campaign.skills.FleetSizeByDP;

import java.awt.Color;

public class FleetSizeByDPNotification implements EveryFrameScript {

    private float CHECK_INTERVAL = Global.getSettings().getFloat("overDPNotificationInterval");
    private float secSinceLastCheck = 0f;
    //v1.0.3
    private boolean initialNotificationSent = false;
    
    @Override
    public boolean isDone() {
        return false;
    }
    
    @Override
    public boolean runWhilePaused() {
        return false;
    }

    @Override
    public void advance(float amount) {
        secSinceLastCheck += amount;

        checkStatus();
    }

    private void checkStatus() {

        if(secSinceLastCheck >= CHECK_INTERVAL) {
            //v1.0.3
            if(!initialNotificationSent) {
                notifyOnGameStart();
            }

            if(FleetSizeByDP.isFleetOverLimit()) {
                //TBD: break out into separate function like notifyOnGameStart()
                String dp = Integer.toString(Math.round(FleetSizeByDP.getDPOverLimit()));
                String supplyPercent = Integer.toString(Math.round(FleetSizeByDP.getSupplyPenaltyInPercent()));
                String header = "FLEET SIZE BY DP:";
                String overMessage = "Your fleet is over its maximum DP allowance by %s DP.  Supply use increased by %s%% and maximum burn speed reduced.";

                Global.getSector().getCampaignUI().addMessage(header,Color.RED);
                Global.getSector().getCampaignUI().addMessage(overMessage,Color.RED, dp, supplyPercent, Color.WHITE, Color.WHITE);
            }

            resetTimer();
        }
    }

    private void resetTimer() {
        secSinceLastCheck = 0f;
    }

    //1.0.3: add notification that Fleet Size by DP is loaded and current DP setting
    private void notifyOnGameStart() {

        String maxFleetDP = Integer.toString(Global.getSettings().getInt("maxShipsInPlayerFleetByDP"));
        String message = "Fleet Size by DP enabled: your max fleet size is %s DP.  Check this mod's README for more information.";
        Global.getSector().getCampaignUI().addMessage(message, Color.CYAN, maxFleetDP, "NA", Color.GREEN, Color.GREEN);
        initialNotificationSent = true;
    }
}
