package FleetSizeByDP.com.starfarer.api.impl.campaign.skills;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.skills.BaseSkillEffectDescription;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetDataAPI;
import com.fs.starfarer.api.characters.FleetTotalItem;
import com.fs.starfarer.api.characters.FleetTotalSource;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.ShipSkillEffect;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

/*
* Skill that checks current player fleet DP and applies increased supply use/burn speed reduction if over the limit.
* This skill should only ever be assigned to the player character, for obvious reasons.
*/
public class FleetSizeByDP {

    //settings.json values
    private static int MAX_FLEET_BY_DP = Global.getSettings().getInt("maxShipsInPlayerFleetByDP");
    private static float SUPPLY_PENALTY_MULT = Global.getSettings().getFloat("suppliesPerShipOverMaxInFleet");
    private static float BURN_PENALTY_POW = Global.getSettings().getFloat("burnPenaltyOverDP");

    //tracking variables for current fleet status.  Used by FleetSizeByDPNotification
    private static boolean fleetOverLimit = false;
    private static float DPOverLimit = 0;
    private static float supplyPenaltyInPercent = 0;

    //helper function for current player fleet DP
    public static float getCurrentFleetDP() {

        //v1.0.3 replace previous check with isInCampaign(), which includes previous logic
        if(BaseSkillEffectDescription.isInCampaign()) {

            CampaignFleetAPI fleet = Global.getSector().getPlayerFleet();
            MutableCharacterStatsAPI stats = Global.getSector().getPlayerStats();

            float totalDP = BaseSkillEffectDescription.getTotalOP(fleet.getFleetData(), stats);
            
            return totalDP;
        }
        else {
            return 0f;
        }
    }

    //getter functions for fleet status and associated penalties.  Used by FleetSizeByDPNotification
    public static boolean isFleetOverLimit() {
        return fleetOverLimit;
    }

    public static float getDPOverLimit() {
        return DPOverLimit;
    }

    public static float getSupplyPenaltyInPercent() {
        return supplyPenaltyInPercent;
    }

    //Level1: implements supply use modifier
    public static String SUPPLIES_BY_FLEET_DP = "fsdp_supply_use_mult_by_dp";
    public static class Level1 extends BaseSkillEffectDescription implements ShipSkillEffect, FleetTotalSource {

        //display OP total on fleet page
        public FleetTotalItem getFleetTotalItem() {
			return getOPTotal();
		}

        public void apply(MutableShipStatsAPI stats, HullSize hullSize, String id, float level) {
            id = SUPPLIES_BY_FLEET_DP;
            float useMult = getFleetSupplyMult(getFleetData(stats));
            stats.getSuppliesPerMonth().modifyMult(id, useMult);

        }

        public void unapply(MutableShipStatsAPI stats, HullSize hullSize, String id) {
            id = SUPPLIES_BY_FLEET_DP;
            stats.getSuppliesPerMonth().unmodify(id);
        }

        public String getEffectDescription(float level) {
            return null;
        }

        public ScopeDescription getScopeDescription() {
			return ScopeDescription.FLEET;
		}

        //calculate fleet supply multiplier
        //v1.0.3 refactor to use caching
        protected float getFleetSupplyMult(FleetDataAPI data) {
            if(data == null) return 1f;

            String key = "fsdpSupplyCalc";
            Float cachedMult = (Float) data.getCacheClearedOnSync().get(key);
    
            if(cachedMult != null) return cachedMult;

            float currentDP = getCurrentFleetDP();

            if(currentDP <= MAX_FLEET_BY_DP) {

                fleetOverLimit = false;
                DPOverLimit = 0;
                supplyPenaltyInPercent = 0;
                
                data.getCacheClearedOnSync().put(key,1f);

                return 1f;
            } 
            else {
                float baseMult = 1 + Math.max(SUPPLY_PENALTY_MULT, 0);
                float fleetOverMult = (currentDP / MAX_FLEET_BY_DP);

                fleetOverLimit = true;
                DPOverLimit = currentDP - MAX_FLEET_BY_DP;
                supplyPenaltyInPercent = ((baseMult * fleetOverMult) - 1) * 100;

                float finalMult = baseMult * fleetOverMult;

                data.getCacheClearedOnSync().put(key,finalMult);

                return finalMult;
            }
        }
    }

    //Level 2: implements burn speed multiplier
    //TBD: (maybe) refactor to work similarly to the vanilla Navigation skills,
    //since calc is only applied to fleet as a whole?
    public static String BURN_MULT_BY_FLEET_DP = "fsdp_burn_mult_by_dp";
    public static class Level2 extends BaseSkillEffectDescription implements ShipSkillEffect, FleetTotalSource {

        public FleetTotalItem getFleetTotalItem() {
			return getOPTotal();
		}

        public void apply(MutableShipStatsAPI stats, HullSize hullSize, String id, float level) {
            id = BURN_MULT_BY_FLEET_DP;

            float burnMult = getFleetBurnMult(getFleetData(stats));
            String description = "Over maximum DP burn penalty";

            //v1.0.3 replace previous logic with isInCampaign()
            if(isInCampaign()) {
                CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
                playerFleet.getStats().getFleetwideMaxBurnMod().modifyMult(id, burnMult, description);
            }

        }

        public void unapply(MutableShipStatsAPI stats, HullSize hullSize, String id) {
            id = BURN_MULT_BY_FLEET_DP;

            //v1.0.3 replace previous logic with isInCampaign()
            if(isInCampaign()) {
                CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
                playerFleet.getStats().getFleetwideMaxBurnMod().unmodifyMult(id);
            }
        }

        public String getEffectDescription(float level) {
            return null;
        }

        public ScopeDescription getScopeDescription() {
			return ScopeDescription.FLEET;
		}
        
        //v1.0.3 update implementation using caching 
        protected float getFleetBurnMult(FleetDataAPI data) {
            if(data == null) return 1f;

            String key = "fsdpBurnCalc";
            Float cachedMult = (Float) data.getCacheClearedOnSync().get(key);
    
            if(cachedMult != null) return cachedMult;

            float currentDP = getCurrentFleetDP();

            float fleetOverMult = 1f;

            if(currentDP <= MAX_FLEET_BY_DP) {
                data.getCacheClearedOnSync().put(key, fleetOverMult);
                return fleetOverMult;
            }
            else {
                float power = Math.max(1, BURN_PENALTY_POW);
                fleetOverMult = MAX_FLEET_BY_DP / currentDP;
                float finalMult = (float) Math.pow(fleetOverMult, power);
                data.getCacheClearedOnSync().put(key, finalMult);
                return finalMult;             
            }
        }

    } 

}
